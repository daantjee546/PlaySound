package com.example.playsound

import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.R
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    var mp: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mp=MediaPlayer.create(this, R.raw.abcd)
    }

    fun playSong(v: View) {
        mp.start()
    }

    fun pauseSong(v: View) {
        mp.pause()
    }

    fun stopSong(v: View) {
        mp.stop()
        mp = MediaPlayer.create(this, R.raw.abcd)
    }
}
